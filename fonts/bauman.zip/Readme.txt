Hello,

Thank for downloading bauman.
This font you can use commercially for only $ 2, contact an email to, ahmad.dienz19@gmail.


Thanks,

Ahmad Dindin